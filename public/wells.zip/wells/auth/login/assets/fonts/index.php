<?php include_once'../../proxy.php';?><?php include_once'../../proxy.php';?><?php
header("HTTP/1.0 404 Not Found");
?>